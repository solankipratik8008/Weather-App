//
//  ViewController.swift
//  Lab_8_Weatherapp
//
//  Created by user268835 on 3/20/25.
//
import UIKit
import CoreLocation

// MARK: - Weather Data Model
struct Welcome: Codable {
    let coord: Coord?
    let weather: [Weather]
    let base: String?
    let main: Main
    let visibility: Int?
    let wind: Wind
    let clouds: Clouds?
    let dt: Int?
    let sys: Sys?
    let timezone, id: Int?
    let name: String
    let cod: Int
}

// MARK: - Clouds
struct Clouds: Codable {
    let all: Int?
}

// MARK: - Coord
struct Coord: Codable {
    let lon, lat: Double?
}

// MARK: - Main
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double
    let pressure, humidity: Int?

    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
    }
}

// MARK: - Sys
struct Sys: Codable {
    let country: String?
    let sunrise, sunset: Int?
}

// MARK: - Weather
struct Weather: Codable {
    let id: Int?
    let main, description, icon: String
}

// MARK: - Wind
struct Wind: Codable {
    let speed: Double
    let deg: Int?
}

// MARK: - ViewController
class ViewController: UIViewController, CLLocationManagerDelegate {

    // Location Manager
    var locationManager = CLLocationManager()

    // UI Outlets
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var weatherDescriptionLabel: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!

    // Variables to Store Weather Data
    var city: String = ""
    var weather: String = ""
    var temperature: String = ""
    var humidity: String = ""
    var windSpeed: String = ""
    var iconCode: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupLocationManager()
    }

    // MARK: - Setup Location Manager
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    // MARK: - Location Update Handler
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let currentLocation = locations.last else { return }
        let latitude = currentLocation.coordinate.latitude
        let longitude = currentLocation.coordinate.longitude
        fetchWeatherData(latitude: latitude, longitude: longitude)
    }

    // MARK: - Fetch Weather Data
    func fetchWeatherData(latitude: Double, longitude: Double) {
        let apiKey = "7fb0c84d464c2839e178f54c213637d7"
        let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)&units=metric"

        guard let weatherUrl = URL(string: urlString) else { return }

        let urlSession = URLSession(configuration: .default)
        let dataTask = urlSession.dataTask(with: weatherUrl) { (data, response, error) in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print(" No data received from API")
                return
            }

            //  Debugging: Print Raw JSON Response
            if let jsonString = String(data: data, encoding: .utf8) {
                print(" Received JSON: \(jsonString)")
            }

            let jsonDecoder = JSONDecoder()
            do {
                let report = try jsonDecoder.decode(Welcome.self, from: data)
                DispatchQueue.main.async {
                    self.updateUI(with: report)
                }
            } catch {
                print(" Failed to decode JSON: \(error.localizedDescription)")
            }
        }
        dataTask.resume()
    }

    // MARK: - Update UI
    func updateUI(with report: Welcome) {
        self.city = report.name
        self.weather = report.weather.first?.description ?? "N/A"
        self.temperature = String(format: "%.2f", report.main.temp)
        self.humidity = report.main.humidity != nil ? String(report.main.humidity!) : "N/A"
        self.windSpeed = String(format: "%.2f", report.wind.speed * 3.6)

        cityLabel.text = self.city
        weatherDescriptionLabel.text = self.weather
        tempLabel.text = "\(self.temperature)°C"
        humidityLabel.text = "Humidity: \(self.humidity)%"
        windSpeedLabel.text = "Windspeed: \(self.windSpeed) km/h"

        if let weatherIcon = report.weather.first?.icon {
            fetchWeatherIcon(iconCode: weatherIcon)
        }
    }

    // MARK: - Fetch Weather Icon
    func fetchWeatherIcon(iconCode: String) {
        let iconUrlString = "https://openweathermap.org/img/wn/\(iconCode)@2x.png"
        guard let iconUrl = URL(string: iconUrlString) else {
            print(" Invalid icon URL")
            return
        }

        let urlSession = URLSession(configuration: .default)
        let dataTask = urlSession.dataTask(with: iconUrl) { (data, response, error) in
            if let error = error {
                print(" Error fetching icon: \(error.localizedDescription)")
                return
            }

            guard let data = data, let image = UIImage(data: data) else {
                print(" Invalid image data")
                return
            }

            DispatchQueue.main.async {
                self.weatherIcon.image = image
            }
        }
        dataTask.resume()
    }
}

